#!/usr/bin/env python

import rospy
import message_filters
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import imutils

class LineFollower:
    def __init__(self, name):
        self.name = name
        self.bridge = CvBridge()
        self.image = None
        self.detected = False

        # Define the topic names
        colour_image_topic = "/camera/rgb/image_raw"
        depth_image_topic = "/camera/depth/image_raw"

        # Create the individual subscribers
        colour_sub = message_filters.Subscriber(colour_image_topic, Image)
        depth_sub = message_filters.Subscriber(depth_image_topic, Image)

        # Synchronize messages based on timestamps
        self.camera_sync = message_filters.TimeSynchronizer([colour_sub, depth_sub], 10)
        self.camera_sync.registerCallback(self.callback_camera)

        # Create a publisher for Twist messages
        self.cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)

    def callback_camera(self, colour_msg, depth_msg):
        #rospy.loginfo("[%s] callback_camera()", self.name)
        colour_image = self.bridge.imgmsg_to_cv2(colour_msg, desired_encoding='bgr8')
        depth_image = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding="passthrough")

        beacon = self.beacon_detect(colour_image, depth_image)

        # Obstacle detection
        dh, dw = depth_image.shape
        centre_depth = depth_image[dh/2, dw/2]
        print(centre_depth)
        threshold = 0.80
        if centre_depth > 0.0 and centre_depth < threshold:
            self.stop()
            print("Waiting for clearance")
            return
        #print(beacon)
        if beacon != None and self.detected == False and beacon < 1.0:
            self.stop()
            rospy.sleep(3)  # Stop for 3 seconds
            self.detected = True
            #print("Done, now move on \n\n")

        # Find target object based on HSV values
        hsv = cv2.cvtColor(colour_image, cv2.COLOR_BGR2HSV)
        lower_yellow = (25, 200, 100)
        upper_yellow = (35, 255, 255)

        lower_red = (0, 200, 100)
        upper_red = (5, 255, 255)

        #mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        #mask = cv2.inRange(hsv, lower_red, upper_red)
        yellow_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        red_mask = cv2.inRange(hsv, lower_red, upper_red)
        # Combine yellow and red masks
        mask = cv2.bitwise_or(yellow_mask, red_mask)

        # Yellow
        yellow_mask = cv2.erode(yellow_mask, None, iterations=2)
        yellow_mask = cv2.dilate(yellow_mask, None, iterations=2)

        # Keep only the bottom 1/4th of image and left half
        height, width = yellow_mask.shape[:2]
        search_topy = int(1 * height / 4)
        #search_boty = height
        yellow_mask[0:search_topy, 0:width/2] = 0
        #yellow_mask[search_boty:height, 0:width/2] = 0

        # Red
        red_mask = cv2.erode(red_mask, None, iterations=2)
        red_mask = cv2.dilate(red_mask, None, iterations=2)

        # Keep only the bottom 1/4th of the image and right half
        height, width = red_mask.shape[:2]
        search_topr = int(1 * height / 4)
        #search_botr = height
        red_mask[0:search_topr, width/2:width] = 0
        #red_mask[search_botr:height, width/2:width] = 0

        # Find centroid of the line blob
        M = cv2.moments(mask)
        if M['m00'] > 0:
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])
            # Find centroid between red and yellow lines
            red_centroid = cv2.moments(red_mask)
            yellow_centroid = cv2.moments(yellow_mask)
            if red_centroid['m00'] > 0 and yellow_centroid['m00'] > 0:
                red_cx = int(red_centroid['m10'] / red_centroid['m00'])
                red_cy = int(red_centroid['m01'] / red_centroid['m00'])
                yellow_cx = int(yellow_centroid['m10'] / yellow_centroid['m00'])
                yellow_cy = int(yellow_centroid['m01'] / yellow_centroid['m00'])
                cx = int((red_cx + yellow_cx) / 2)
                cy = int((red_cy + yellow_cy) / 2)



            cv2.circle(colour_image, (cx, cy), 20, (0, 255, 0), -1)
            #cv2.circle(mask, (cx, cy), 20, (0, 0, 255), -1)

            # Perform proportional control to keep centroid in the center
            err = cx - width / 2
            
            # Check if yellow or red is detected
            if cv2.countNonZero(yellow_mask) > 1000 and cv2.countNonZero(red_mask) > 1000:
                print("Both are detected")
                self.track_lane(err)
            elif cv2.countNonZero(yellow_mask) > 1000:
                print("Only Yellow is here")
                self.turn_right()
            elif cv2.countNonZero(red_mask) > 1000:
                print("Only Red is here")
                self.turn_left()
            else:
                print("Nothing is detected")
                self.stop()

        self.image = colour_image
        #print("Happen")
        #self.image = red_mask

        if self.image.shape[0] > 0 and self.image.shape[1] > 0:
            cv2.imshow("window", self.image)
            cv2.waitKey(30)

    def stop(self):
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        self.cmd_vel_pub.publish(twist)

    def turn_right(self):
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = -0.1  # Adjust the angular velocity as needed
        self.cmd_vel_pub.publish(twist)

    def turn_left(self):
        twist = Twist()
        twist.linear.x = 0.0
        twist.angular.z = 0.1  # Adjust the angular velocity as needed
        self.cmd_vel_pub.publish(twist)

    def track_lane(self, location):
        twist = Twist()
        twist.linear.x = 0.2  # Constant forward movement
        twist.angular.z = -float(location) / 1000
        # Publish Twist message
        self.cmd_vel_pub.publish(twist)

    def beacon_detect(self, colour_image, depth_image):
        blue_lower = (118,67,63)
        blue_upper = (122,255,207)

        if colour_image is not None:
            blurred = cv2.GaussianBlur(colour_image, (11,11), 0)
            hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, blue_lower, blue_upper)
            mask = cv2.erode(mask, None, iterations=2)
            mask = cv2.dilate(mask, None, iterations=2)
            contours = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contours = imutils.grab_contours(contours)

            if len(contours) > 0:
                largest_contour = max(contours, key=cv2.contourArea)
                x, y, w, h = cv2.boundingRect(largest_contour)
                beacon_centre = (x + w//2, y + h//2)
                top_x = beacon_centre[0]
                top_y = beacon_centre[1]
                depth = depth_image[top_y, top_x]
                return depth

        return None


if __name__ == '__main__':
    rospy.init_node('line_follower', anonymous=True)
    rospy.loginfo("[line_follower] Starting Line Follower Module")
    lf = LineFollower("line_follower")
    try:
        rospy.spin()
    except KeyboardInterrupt:
        rospy.loginfo("[line_follower] Shutting Down Line Follower Module")